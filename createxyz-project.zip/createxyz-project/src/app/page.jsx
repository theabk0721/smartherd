"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [currentLanguage, setCurrentLanguage] = useState("en");
  const [selectedCow, setSelectedCow] = useState(1);
  const [healthData, setHealthData] = useState({
    temperature: "38.5°C",
    heartRate: "65 BPM",
    activityLevel: "Normal",
    respirationRate: "30 BPM",
    rumination: "400 min/day",
    waterIntake: "45 L",
    feedIntake: "22 kg",
    weight: "550 kg",
    mobility: "Good",
    lastHealthCheck: "2024-03-19",
    vaccinations: {
      lastDate: "2024-01-15",
      nextDue: "2024-07-15",
      type: "FMD Vaccine",
    },
    reproduction: {
      status: "Open",
      lastHeat: "2024-03-01",
      daysInMilk: 180,
    },
    medicalHistory: [
      {
        date: "2024-02-15",
        condition: "Mastitis",
        treatment: "Antibiotics",
        outcome: "Resolved",
        vet: "Dr. Smith",
      },
      {
        date: "2024-01-10",
        condition: "Lameness",
        treatment: "Hoof trimming",
        outcome: "Improved",
        vet: "Dr. Johnson",
      },
    ],
    vets: [
      {
        name: "Dr. Sarah Smith",
        specialty: "Dairy Medicine",
        phone: "+91 95xx52897x",
        email: "dr.smith@vetcare.com",
        availability: "24/7",
      },
      {
        name: "Dr. Mike Johnson",
        specialty: "Reproductive Health",
        phone: "+91 94xx52987x",
        email: "dr.johnson@vetcare.com",
        availability: "Mon-Fri 9-5",
      },
    ],
  });

  const [notifications, setNotifications] = useState([
    { id: 1, type: "alert", message: "High temperature detected for Cow #123" },
    { id: 2, type: "reminder", message: "Vaccination due in 2 days" },
    { id: 3, type: "alert", message: "Low feed intake detected for Cow #45" },
    {
      id: 4,
      type: "warning",
      message: "Water intake below normal for Cow #78",
    },
    { id: 5, type: "alert", message: "Abnormal heart rate for Cow #92" },
    { id: 6, type: "reminder", message: "Hoof trimming scheduled next week" },
    { id: 7, type: "warning", message: "Soil moisture levels dropping" },
    {
      id: 8,
      type: "alert",
      message: "Potential mastitis detected in Cow #156",
    },
  ]);

  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState([]);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [weatherData, setWeatherData] = useState(null);
  const [city, setCity] = useState("London");
  const [loading, setLoading] = useState(false);
  const [vetChatInput, setVetChatInput] = useState("");
  const [vetChatMessages, setVetChatMessages] = useState([]);
  const [vetStreamingMessage, setVetStreamingMessage] = useState("");
  const [selectedVet, setSelectedVet] = useState(null);

  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingMessage,
    onFinish: (message) => {
      setChatMessages((prev) => [
        ...prev,
        { role: "assistant", content: message },
      ]);
      setStreamingMessage("");
    },
  });

  const handleVetStreamResponse = useHandleStreamResponse({
    onChunk: setVetStreamingMessage,
    onFinish: (message) => {
      setVetChatMessages((prev) => [
        ...prev,
        { role: "assistant", content: message },
      ]);
      setVetStreamingMessage("");
    },
  });

  const languages = [
    { code: "en", name: "English" },
    { code: "hi", name: "हिंदी" },
    { code: "ta", name: "தமிழ்" },
    { code: "te", name: "తెలుగు" },
    { code: "ml", name: "മലയാളം" },
  ];

  const sendMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = { role: "user", content: chatInput };
    setChatMessages((prev) => [...prev, userMessage]);
    setChatInput("");

    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [...chatMessages, userMessage],
        stream: true,
      }),
    });
    handleStreamResponse(response);
  };

  const sendVetMessage = async () => {
    if (!vetChatInput.trim()) return;

    const userMessage = { role: "user", content: vetChatInput };
    setVetChatMessages((prev) => [...prev, userMessage]);
    setVetChatInput("");

    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content:
              "You are a veterinary support assistant helping with cattle health issues.",
          },
          ...vetChatMessages,
          userMessage,
        ],
        stream: true,
      }),
    });
    handleVetStreamResponse(response);
  };

  const getWeather = async () => {
    try {
      setLoading(true);
      const response = await fetch(
        `/integrations/weather-by-city/weather/${city}`
      );
      const data = await response.json();
      setWeatherData(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const [soilDetails, setSoilDetails] = useState({
    ph: "6.5",
    moisture: "35%",
    nitrogen: "Medium",
    phosphorus: "High",
    potassium: "Low",
    organicMatter: "3.2%",
    texture: "Loamy",
    temperature: "18°C",
  });

  return (
    <div className="min-h-screen bg-gray-50 border-4 border-[#4CAF50]">
      <div className="text-3xl font-bold text-center py-4 bg-[#4CAF50] text-white">
        SMARTHERD
      </div>

      <nav className="bg-[#388E3C] shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between">
            <div className="flex space-x-8">
              <a
                href="#dashboard"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-chart-bar mr-2"></i>
                <span>Dashboard</span>
              </a>
              <a
                href="#health"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-heartbeat mr-2"></i>
                <span>Health</span>
              </a>
              <a
                href="#weather"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-cloud-sun mr-2"></i>
                <span>Weather</span>
              </a>
              <a
                href="#soil"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-seedling mr-2"></i>
                <span>Soil</span>
              </a>
              <a
                href="#vet"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-user-md mr-2"></i>
                <span>Veterinary</span>
              </a>
              <a
                href="#references"
                className="flex items-center py-4 px-2 text-white hover:bg-[#2E7D32] rounded-lg"
              >
                <i className="fas fa-book mr-2"></i>
                <span>References</span>
              </a>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={currentLanguage}
                onChange={(e) => setCurrentLanguage(e.target.value)}
                className="bg-white rounded px-2 py-1"
              >
                {languages.map((lang) => (
                  <option key={lang.code} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </nav>

      <main className="p-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-lg p-4 shadow">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-chart-pie mr-2 text-[#2ecc71]"></i>
              Cattle Statistics
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="text-sm font-bold">Cattle Distribution</div>
                <div>Total Cattle: 150</div>
                <div>Dairy Cows: 80</div>
                <div>Beef Cattle: 50</div>
                <div>Calves: 20</div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-bold">Milk Production</div>
                <div>Daily Yield/Cow: 15L</div>
                <div>Total Daily: 1,200L</div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-bold">Feed & Water</div>
                <div>Feed/Cow: 25kg</div>
                <div>Total Feed: 3,750kg</div>
                <div>Water/Cow: 50L</div>
                <div>Total Water: 7,500L</div>
              </div>
              <div className="space-y-2">
                <div className="text-sm font-bold">Health & Breeding</div>
                <div>Vaccinated: 90%</div>
                <div>Health Issues: 5%</div>
                <div>Pregnant: 10%</div>
                <div>In Heat: 12%</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-poppins flex items-center">
                <i className="fas fa-heartbeat mr-2 text-[#e74c3c]"></i>
                Health Monitor
              </h2>
              <select
                value={selectedCow}
                onChange={(e) => setSelectedCow(Number(e.target.value))}
                className="p-2 border rounded"
              >
                {[...Array.from({ length: 150 })].map((_, i) => (
                  <option key={i + 1} value={i + 1}>
                    Cow #{i + 1}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-temperature-high text-[#e74c3c] text-xl"></i>
                <div className="mt-2 text-sm">Temperature</div>
                <div className="font-bold">{healthData.temperature}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-heart text-[#e74c3c] text-xl"></i>
                <div className="mt-2 text-sm">Heart Rate</div>
                <div className="font-bold">{healthData.heartRate}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-lungs text-[#3498db] text-xl"></i>
                <div className="mt-2 text-sm">Respiration</div>
                <div className="font-bold">{healthData.respirationRate}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-walking text-[#3498db] text-xl"></i>
                <div className="mt-2 text-sm">Activity</div>
                <div className="font-bold">{healthData.activityLevel}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-weight text-[#9b59b6] text-xl"></i>
                <div className="mt-2 text-sm">Weight</div>
                <div className="font-bold">{healthData.weight}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-glass-water text-[#2980b9] text-xl"></i>
                <div className="mt-2 text-sm">Water Intake</div>
                <div className="font-bold">{healthData.waterIntake}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-utensils text-[#27ae60] text-xl"></i>
                <div className="mt-2 text-sm">Feed Intake</div>
                <div className="font-bold">{healthData.feedIntake}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-sync text-[#8e44ad] text-xl"></i>
                <div className="mt-2 text-sm">Rumination</div>
                <div className="font-bold">{healthData.rumination}</div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="p-3 bg-gray-50 rounded">
                <h3 className="font-bold text-sm mb-2">Vaccination Status</h3>
                <div className="text-sm">
                  <div>Last: {healthData.vaccinations.lastDate}</div>
                  <div>Next: {healthData.vaccinations.nextDue}</div>
                  <div>Type: {healthData.vaccinations.type}</div>
                </div>
              </div>
              <div className="p-3 bg-gray-50 rounded">
                <h3 className="font-bold text-sm mb-2">Reproduction Status</h3>
                <div className="text-sm">
                  <div>Status: {healthData.reproduction.status}</div>
                  <div>Last Heat: {healthData.reproduction.lastHeat}</div>
                  <div>Days in Milk: {healthData.reproduction.daysInMilk}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-cloud-sun mr-2 text-[#f39c12]"></i>
              Weather Information
            </h2>
            <div className="flex flex-col space-y-4">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="flex-1 p-2 border rounded"
                  placeholder="Enter city name"
                />
                <button
                  onClick={getWeather}
                  disabled={loading}
                  className="px-4 py-2 bg-[#4CAF50] text-white rounded"
                >
                  {loading ? "Loading..." : "Get Weather"}
                </button>
              </div>
              {weatherData && (
                <div className="text-center p-4 bg-gray-50 rounded">
                  <div className="text-xl font-bold">
                    {weatherData.location.name}
                  </div>
                  <div className="text-lg">{weatherData.current.temp_c}°C</div>
                  <div>{weatherData.current.condition.text}</div>
                  <img
                    src={weatherData.current.condition.icon}
                    alt="Weather condition"
                    className="mx-auto"
                  />
                </div>
              )}
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-bell mr-2 text-[#f39c12]"></i>
              Alerts & Notifications
            </h2>
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 rounded flex items-center justify-between ${
                    notification.type === "alert"
                      ? "bg-[#ffe6e6]"
                      : notification.type === "warning"
                      ? "bg-[#fff7e6]"
                      : "bg-[#e6ffe6]"
                  }`}
                >
                  <div className="flex items-center">
                    <i
                      className={`fas ${
                        notification.type === "alert"
                          ? "fa-exclamation-circle text-[#e74c3c]"
                          : notification.type === "warning"
                          ? "fa-triangle-exclamation text-[#f39c12]"
                          : "fa-clock text-[#2ecc71]"
                      } mr-2`}
                    ></i>
                    {notification.message}
                  </div>
                  <button
                    onClick={() => {
                      setNotifications(
                        notifications.filter((n) => n.id !== notification.id)
                      );
                    }}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-comments mr-2 text-[#2ecc71]"></i>
              AI Assistant
            </h2>
            <div className="flex flex-col h-[300px]">
              <div className="flex-1 overflow-y-auto mb-4 space-y-2">
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded ${
                      msg.role === "user"
                        ? "bg-gray-100 ml-8"
                        : "bg-[#4CAF50] bg-opacity-10 mr-8"
                    }`}
                  >
                    {msg.content}
                  </div>
                ))}
                {streamingMessage && (
                  <div className="p-2 rounded bg-[#4CAF50] bg-opacity-10 mr-8">
                    {streamingMessage}
                  </div>
                )}
              </div>
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && sendMessage()}
                  className="flex-1 p-2 border rounded"
                  placeholder="Ask a question..."
                />
                <button
                  onClick={sendMessage}
                  className="px-4 py-2 bg-[#4CAF50] text-white rounded"
                >
                  Send
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-seedling mr-2 text-[#8e44ad]"></i>
              Soil Details
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-vial text-[#8e44ad] text-xl"></i>
                <div className="mt-2 text-sm">pH Level</div>
                <div className="font-bold">{soilDetails.ph}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-droplet text-[#3498db] text-xl"></i>
                <div className="mt-2 text-sm">Moisture</div>
                <div className="font-bold">{soilDetails.moisture}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-flask text-[#27ae60] text-xl"></i>
                <div className="mt-2 text-sm">Nitrogen</div>
                <div className="font-bold">{soilDetails.nitrogen}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-flask text-[#f39c12] text-xl"></i>
                <div className="mt-2 text-sm">Phosphorus</div>
                <div className="font-bold">{soilDetails.phosphorus}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-flask text-[#e74c3c] text-xl"></i>
                <div className="mt-2 text-sm">Potassium</div>
                <div className="font-bold">{soilDetails.potassium}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-leaf text-[#16a085] text-xl"></i>
                <div className="mt-2 text-sm">Organic Matter</div>
                <div className="font-bold">{soilDetails.organicMatter}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-mountain text-[#95a5a6] text-xl"></i>
                <div className="mt-2 text-sm">Texture</div>
                <div className="font-bold">{soilDetails.texture}</div>
              </div>
              <div className="text-center p-3 bg-gray-50 rounded">
                <i className="fas fa-temperature-half text-[#d35400] text-xl"></i>
                <div className="mt-2 text-sm">Temperature</div>
                <div className="font-bold">{soilDetails.temperature}</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg p-4 shadow col-span-1 md:col-span-2">
            <h2 className="text-lg font-poppins mb-4 flex items-center">
              <i className="fas fa-user-md mr-2 text-[#3498db]"></i>
              Veterinary Support
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded">
                  <h3 className="font-bold mb-2">Medical History</h3>
                  <div className="space-y-2">
                    {healthData.medicalHistory.map((record, index) => (
                      <div key={index} className="bg-white p-3 rounded shadow">
                        <div className="font-semibold">{record.condition}</div>
                        <div className="text-sm">
                          <div>Date: {record.date}</div>
                          <div>Treatment: {record.treatment}</div>
                          <div>Outcome: {record.outcome}</div>
                          <div>Vet: {record.vet}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gray-50 p-4 rounded">
                  <h3 className="font-bold mb-2">On-Call Veterinarians</h3>
                  <div className="space-y-2">
                    {healthData.vets.map((vet, index) => (
                      <div key={index} className="bg-white p-3 rounded shadow">
                        <div className="font-semibold">{vet.name}</div>
                        <div className="text-sm">
                          <div>Specialty: {vet.specialty}</div>
                          <div>Phone: {vet.phone}</div>
                          <div>Email: {vet.email}</div>
                          <div>Availability: {vet.availability}</div>
                        </div>
                        <button
                          onClick={() => setSelectedVet(vet)}
                          className="mt-2 px-3 py-1 bg-[#3498db] text-white rounded text-sm"
                        >
                          Contact
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex flex-col h-[500px]">
                <div className="flex-1 overflow-y-auto mb-4 space-y-2 bg-gray-50 p-4 rounded">
                  {vetChatMessages.map((msg, index) => (
                    <div
                      key={index}
                      className={`p-2 rounded ${
                        msg.role === "user"
                          ? "bg-white ml-8"
                          : "bg-[#3498db] bg-opacity-10 mr-8"
                      }`}
                    >
                      {msg.content}
                    </div>
                  ))}
                  {vetStreamingMessage && (
                    <div className="p-2 rounded bg-[#3498db] bg-opacity-10 mr-8">
                      {vetStreamingMessage}
                    </div>
                  )}
                </div>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={vetChatInput}
                    onChange={(e) => setVetChatInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && sendVetMessage()}
                    className="flex-1 p-2 border rounded"
                    placeholder="Describe the health issue..."
                  />
                  <button
                    onClick={sendVetMessage}
                    className="px-4 py-2 bg-[#3498db] text-white rounded"
                  >
                    Send
                  </button>
                </div>
              </div>
            </div>
          </div>

          {selectedVet && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-lg p-6 max-w-md w-full">
                <h3 className="text-xl font-bold mb-4">
                  Contact {selectedVet.name}
                </h3>
                <div className="space-y-2">
                  <div>
                    <a
                      href={`tel:${selectedVet.phone}`}
                      className="block w-full text-center py-2 bg-[#3498db] text-white rounded mb-2"
                    >
                      Call Now
                    </a>
                  </div>
                  <div>
                    <a
                      href={`mailto:${selectedVet.email}`}
                      className="block w-full text-center py-2 bg-[#2ecc71] text-white rounded mb-2"
                    >
                      Send Email
                    </a>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedVet(null)}
                  className="mt-4 w-full py-2 bg-gray-200 text-gray-700 rounded"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg p-4 shadow mt-4">
          <h2 className="text-lg font-poppins mb-4 flex items-center">
            <i className="fas fa-book mr-2 text-[#3498db]"></i>
            References
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 bg-gray-50 rounded">
              <h3 className="font-bold text-sm mb-2">Technical Info</h3>
              <ul className="text-sm space-y-1">
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Cattle Management Guide
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Health Monitoring Manual
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Feed & Nutrition Guide
                  </a>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded">
              <h3 className="font-bold text-sm mb-2">Research Papers</h3>
              <ul className="text-sm space-y-1">
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Smart Farming Technologies
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Cattle Health Analytics
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Soil Management Research
                  </a>
                </li>
              </ul>
            </div>

            <div className="p-4 bg-gray-50 rounded">
              <h3 className="font-bold text-sm mb-2">External Resources</h3>
              <ul className="text-sm space-y-1">
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Agricultural Department
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Veterinary Association
                  </a>
                </li>
                <li>
                  <a href="#" className="text-blue-600 hover:underline">
                    Weather Service
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default MainComponent;